import React from 'react';
import ReactDOM from 'react-dom';
import App from './AllComponents/App';
import 'react-bootstrap'

ReactDOM.render(
  <App/>,
  document.getElementById('root')
);
